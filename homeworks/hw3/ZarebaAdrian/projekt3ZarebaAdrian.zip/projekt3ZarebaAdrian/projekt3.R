library("dplyr")
library(tidyverse)


population2020 <- read.csv("C:\\Users\\zareb\\OneDrive\\Desktop\\Studies\\3 semestr\\R\\projekt1\\czekolada\\population.csv") %>%
  select(name, pop2020) %>%
  mutate(pop2020 = pop2020 * 1000) %>%
  rename(region = name) %>%
  mutate(region = replace(region, region == "Japan", "Japan*")) %>%
  mutate(region = replace(region, region == "United Kingdom", "Great Britain")) %>%
  arrange(desc(pop2020)) %>%
  head(10)

mapdata <- map_data("world")
joined <- left_join(mapdata, population2020, by = "region") %>%
  arrange(desc(pop2020))

################################################################################
map <- ggplot(joined, aes(x = long, y = lat, group = group)) +
  geom_polygon(aes(fill = pop2020)) +
  scale_fill_gradient(name = "count", trans = "log") +
  theme(axis.text.x = element_blank(),
        axis.text.y = element_blank(),
        rect = element_blank(),
        axis.ticks = element_blank(),
        axis.title.x = element_blank(),
        axis.title.y = element_blank(),
        plot.background = element_blank()) +
  guides(fill=guide_legend(title="Zaludnienie w mln")) +
  ggtitle("Ilosc mieszkancow 10-najbardziej zaludnionych panstw")

map

################################################################################
library(scales)

population2020 <- population2020 %>%
  mutate(pop2020 = pop2020/1000000)

wykres <- ggplot(population2020, aes(x = reorder(region, pop2020), y = pop2020)) +
  geom_col() +
  scale_y_continuous(labels = comma, breaks = pretty(population2020$pop2020, n = 10)) +
  xlab("Kraj") +
  ylab("Ludnosc w mln") +
  ggtitle("Ilosc mieszkancow 10-najbardziej zaludnionych panstw")
  
wykres


################################################################################

wykres2 <- ggplot(population2020, aes(x="", y=reorder(pop2020, pop2020), fill=region)) +
  geom_bar(stat="identity", width=1) +
  coord_polar("y", start=0) +
  theme(axis.text = element_blank(),
        axis.ticks = element_blank(),
        panel.grid  = element_blank()) +
  xlab("") +
  ylab("") +
  ggtitle("Ilosc mieszkancow 10-najbardziej zaludnionych panstw")
  

wykres2
